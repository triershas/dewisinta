<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet" type="text/css" href="style.css">
	
	<script type="text/javascript" src="jquery.js"></script>
</head>
<body>

<div class="content">
	<h2><center>Perpustakaan</center></h2>
	<h4><center>SMK N 1 Bawang, Banjarnegara</center></h4>
	<div class="menu">
		<ul>
			<li><a href="index2.php?page=home">HOME</a></li>
			<li><a href="index2.php?page=tentang">TENTANG</a></li>
			<li><a href="index2.php?page=tutorial">TUTORIAL</a></li>
		</ul>
	</div>
 
	<div class="badan">
 
 <?php
include "koneksi.php";
$select = "select * from pelanggaran order by id_daftar desc";
$select_query = mysql_query($select);
?>
<center>
<table borer="1">