<!DOCTYPE html>
<html>
<head>
	<center><title></title></center>s
</head>
<body>
 
	<a href="index.php">KEMBALI</a>
	
	<h3>EDIT TARI NUSANTARA</h3>
 
	<?php
	include 'koneksi.php';
	$id = $_GET['id'];
	$data = mysqli_query($koneksi,"select * from mahasiswa where id='$id'");
	while($d = mysqli_fetch_array($data)){
		?>
		<form method="post" action="update.php">
			<table>
				<tr>			
					<td>Nama Tari</td>
					<td>
						<input type="hidden" name="id" value="<?php echo $d['id']; ?>">
						<input type="varchar" name="nama_tari" value="<?php echo $d['nama_tari']; ?>">
					</td>
				</tr>
				<tr>
					<td>Deskripsi</td>
					<td><input type="number" name="nis" value="<?php echo $d['deskripsi']; ?>"></td>
				</tr>
				<tr>
					<td>Alat musik</td>
					<td><input type="text" name="alamat" value="<?php echo $d['alat_musik']; ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="SIMPAN"></td>
				</tr>		
			</table>
		</form>
		<?php 
	}
	?>
 
</body>
</html>