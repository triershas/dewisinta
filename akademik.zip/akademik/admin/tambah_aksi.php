<?php

include 'koneksi.php';
 
$nama_tari = $_POST['nama_tari'];
$daerah_asal = $_POST['deskripsi'];
$alat_musik = $_POST['alat_musik'];
 
mysqli_query($koneksi,"insert into mahasiswa values('','$nama_tari','$daerah_asal','$alat_musik')");

header("location:index2.php");

 
?>