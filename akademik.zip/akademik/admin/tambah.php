<html>
<head>
	<center><title>daftar</title></center>
</head>
<body>
 
	<h2>TARI TRADISIONAL BANJARNEGARA</h2>
	
	<h3>Isi Dibawah Ini</h3>
	
	<form method="post" action="tambah_aksi.php">
		<table>
			<tr>			
				<td>Nama Tari</td>
				<td><input type="text" name="nama_tari"></td>
			</tr>
		
			<tr>
				<td>Deskripsi</td>
				<td><input type="text" name="deskripsi"></td>
			</tr>
			<tr>
				<td>Alat Musik</td>
				<td><input type="text" name="alat_musik"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
	<a href="index2.php">KEMBALI</a>
</body>
</html>