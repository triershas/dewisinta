<?php 

include 'koneksi.php';
 
$id = $_POST['id'];
$nama_tari = $_POST['nama_tari'];
$deskripsi = $_POST['deskripsi'];
$alat_musik = $_POST['alat_musik'];
 
mysqli_query($koneksi,"update mahasiswa set nama='$nama_tari', nis='$daerah_asal', alamat='$alat_musik' where id='$id'");
 
header("location:index2.php");
 
?>